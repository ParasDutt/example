import logo from './logo.svg';
import './App.css';
import  Header  from "./my components/Header";
import  Middlepart  from "./my components/Middlepart";
import  Footer  from "./my components/Footer";

function App() {
  return (
    <>
   <Header/>
  <Middlepart/>
  <Footer/>
  </>
  );
}

export default App;
